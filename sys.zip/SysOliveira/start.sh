#!/bin/sh

chmod +x GestaoRepresentante.jar

